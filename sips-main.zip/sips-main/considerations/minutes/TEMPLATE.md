# INSERT_NAME CAB Minutes

## Meeting Information

**Location:**

**Recorded:**

**Date:** Month Day, Year

**Time:** 24hr time in UTC

**Attendees:**

- Full Name

**Topic(s):**

- List of topics to be discussed

**Materials**:

- List of supporting materials

## Meeting Notes

- List of general meeting notes

## Action Items

- List of action items
- Note markdown format below:
  - [ ] open task
  - [x] completed task

## Vote Outcome(s)

- List of voting outcomes per CAB member
