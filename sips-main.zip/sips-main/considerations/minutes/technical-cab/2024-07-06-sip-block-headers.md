# Technical CAB Minutes

## Meeting Information

**Location:** Discord

**Recorded:** No

**Date:**

- July 1st, 2024

**Time:**

**Attendees:**

-

**Topic(s):**

- Vote on SIP: Update for get-block-info

**Materials**:

- [SIP: Update for get-block-info](https://github.com/stacksgov/sips/pull/178)

## 2024-01-31 Meeting Notes

-

### Vote Outcome

Quorum is reached with 6 eligible CAB members voting on the SIP.

| Name         | Vote    |
| ------------ | ------- |
| Dan Trevino  | yes     |
| Aaron B      | yes     |
| Mike Cohen   | yes     |
| Vlad         | yes     |
| 0xdima95     | yes     |
| Jesse Wiley  | yes     |
