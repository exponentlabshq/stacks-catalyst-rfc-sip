# Technical CAB Minutes

## Meeting Information

**Location:** Discord

**Recorded:** No

**Date:**

- November 14th, 2024

**Time:**

**Attendees:**

- **Topic(s):**

- Vote on SIP: Bootstrapping sBTC Liquidity and Nakamoto Signer Incentives

**Materials**:

- [SIP-029: Preserving Economic Incentives During Stacks Network Upgrades](https://github.com/stacksgov/sips/pull/196)

## 2024-01-31 Meeting Notes

-

### Vote Outcome

Quorum is reached with 9 eligible CAB members voting on the SIP.

| Name             | Vote |
| ---------------- | ---- |
| Aaron Blankstein | yes  |
| Ashton Stephens  | yes  |
| Brice Dobry      | yes  |
| j2p2             | yes  |
| Friedger         | no   |
| Jesse Wiley      | -    |
| Mike Cohen       | yes  |
| 0xdima           | yes  |
| setzeus          | yes  |
| Vlad             | yes  |
