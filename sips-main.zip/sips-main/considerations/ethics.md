# Consideration for Ethics SIPs

Chairperson: Jude Nelson

Members:

- Jude Nelson <jude@stacks.org>
- Juliet Oberding <juliet.oberding@gmail.com>

Discussions-to: https://github.com/stacksgov/sips

Created-by: SIP-000

## About

This consideration advisory board is a place-holder for advancing SIPs from Recommended status.

Until there are at least three members of this board who are not on the steering committee, it shall be run by the steering committee.

_If this CAB interests you and you wish to join the effort, please reach out to @jennymith and @Hero-Gamer or Steering Committee members @jcnelson and @GinaAbrams_
