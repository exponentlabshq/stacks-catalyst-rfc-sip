Stacks Improvement Proposals
============================

Each directory here contains a Stacks Improvement Proposal as well as all
supplementary materials.

New SIPs may be submitted via pull request, but please make sure they adhere to
the standards described in
[SIP-000](./sip-000/sip-000-stacks-improvement-proposal-process.md).
